﻿using System;
using System.IO;
using System.Text.RegularExpressions;
using formatException.Model;


namespace formatException
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string[] names = new string[3];
            int[] marks = new int[3];
            for(int i = 0; i < 3; i++)
            {
                Console.Write("Enter the  student names and marks \n");
                names[i] = Console.ReadLine();
                try
                {
                    marks[i] = Convert.ToInt32(Console.ReadLine());
                    check(marks[i]);
                }
                catch (FormatException)
                {
                    Console.WriteLine("{0} is not a integer number  \n", marks[i]);
                }
                catch (NegativeNumberException e)
                {
                    Console.WriteLine(e);
                }
                finally
                {
                    Person emp1 = new Person();
                    emp1.person("Tanveer", "Khan", "faizykhanfzk@gmail.com", Convert.ToDateTime("11/07/1997"));
                }
            }
        }
        public static void check(int num)
        {
            if (num < 0)
            {
                throw new NegativeNumberException("Negative not allowed");
            }
        }
    }
}
