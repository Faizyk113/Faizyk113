select  
ProductName,
SalesOrderID
from master.dbo.Products 
join AdventureWorks2012.Sales.SalesOrderDetail
on products.ProductID != SalesOrderID;
