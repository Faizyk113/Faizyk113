select BusinessEntityID, LoginID ,
JobTitle
from HumanResources.Employee 
where JobTitle = 'Research and Development Engineer';