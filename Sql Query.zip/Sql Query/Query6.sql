use AdventureWorks2012
Select JobTitle,
BirthDate, FirstName , LastName
from HumanResources.Employee
Join Person.Person on
Employee.BusinessEntityID = Person.BusinessEntityID
order by Person.BusinessEntityID;