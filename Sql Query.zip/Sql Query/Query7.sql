use AdventureWorks2012
Select CustomerID,
StoreID, TerritoryID , FirstName, MiddleName,LastName
from Sales.Customer
Join Person.Person on
person.BusinessEntityID = PersonID
order by PersonID;