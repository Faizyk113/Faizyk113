use AdventureWorks2012
select * from Production.ProductCostHistory Where ModifiedDate  = '2003-06-17'; 