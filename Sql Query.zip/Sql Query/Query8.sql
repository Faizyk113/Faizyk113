
select 
SalesOrderID
ContactName,
CompanyName 
from master.dbo.Customers
join AdventureWorks2012.Sales.SalesOrderHeader
on SalesOrderID = Customers.CustomerID;