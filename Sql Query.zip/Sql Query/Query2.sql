use master
select 
CustomerID,
ContactName,
CompanyName
From Customers