use AdventureWorks2012
Select BusinessEntityID,
FirstName,
MiddleName,
LastName
from Person.Person where MiddleName = 'E' or MiddleName = 'B';
