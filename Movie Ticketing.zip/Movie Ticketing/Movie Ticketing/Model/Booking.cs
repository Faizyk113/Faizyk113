﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Movie_Ticketing.Model;

namespace Movie_Ticketing.Model
{
    public  class Booking
    {
        public int BookingId;
        public DateTime BookingDate;
        public int ShowID;
        private string _CustomerName;
        public string CustomerName
        {
            get { return _CustomerName; }
            set
            {
                if(string.IsNullOrEmpty(value)|| value == "")
                {
                    Console.WriteLine("The Customer name is not There \n");
                }
                else
                {
                    _CustomerName = value;
                }
            }
        }
        private int _NumberOfSeats;
        public int NumberOfSeats
        {
            get { return _NumberOfSeats; }
            set
            {
                if(0 < value || value <= 4)
                {
                    _NumberOfSeats = value;
                }
                else
                {
                    Console.WriteLine("Seat number should be between 1 and 4 including range. \n");
                }
            }
            
        }
        private string _SeatType;
        public string SeatType
        {
            get { return _SeatType; }
            set
            {
                if (value.Equals("platinum", StringComparison.InvariantCultureIgnoreCase) || value.Equals("gold", StringComparison.InvariantCultureIgnoreCase) || value.Equals("silver", StringComparison.InvariantCultureIgnoreCase))
                {
                    _SeatType = value;
                }
                else
                {
                    Console.WriteLine("Invalid Seat type");
                }
            }
        }
        public decimal Amount;
        private string _Email;
        public string Email
        {
            get { return _Email; }
            set
            {
                if(string.IsNullOrEmpty(value) || value == "")
                {
                    Console.WriteLine("Email is not there or Empty Email. \n");
                }
                else
                {
                    _Email = value;
                }
            }
        }
        public string BookingStatus;
        public static List<int> SeatNumbers = new List<int>();

        public Booking(int ShowID_, string CustomerName_, int NumberOfSeats_,  string SeatType_, string Email_)
        {
            Random random = new Random();
            this.BookingId = random.Next(1000, 100000);
            this.ShowID = ShowID_;
            this.CustomerName = CustomerName_;
            this.NumberOfSeats = NumberOfSeats_;
            this.SeatType = SeatType_;
            this.Email = Email_;    
            for(int i = 0; i < MovieTicketing.shows.Count; i++)
            {
                var k = MovieTicketing.shows[i];
                if(k.ShowID == ShowID)
                {
                    if(SeatType.Equals("platinum", StringComparison.InvariantCultureIgnoreCase))
                    {
                        Amount = NumberOfSeats * k.PlatinumSeatRate;
                    }
                    if(SeatType.Equals("gold", StringComparison.InvariantCultureIgnoreCase))
                    {
                        Amount = NumberOfSeats * k.GoldSeatRate;
                    }
                    if(SeatType.Equals("silver", StringComparison.InvariantCultureIgnoreCase))
                    {
                        Amount = NumberOfSeats * k.SilverSeatRate;
                    }
                }
            }
        }

    }
}
