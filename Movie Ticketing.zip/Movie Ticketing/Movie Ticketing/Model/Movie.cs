﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Ticketing.Model
{
    public class Movie
    {
        public int MovieID { get; set; }
        private string _MovieName;
        public string MovieName
        {
            get { return _MovieName; }
            set { if (value == null || value == " ")
                {
                    Console.WriteLine("The Movie Name is Empty. \n");
                }
                else
                {
                    _MovieName = value;
                }

            }
        }

        private string _Director;
        public string Director
        {
            get { return _Director; }
            set { if (value == null || value == string.Empty || value == " ")
                {
                    Console.WriteLine("The Director Name is Empty . / Try again \n");
                }
                else
                {
                    _Director = value;
                }
                                                
                }
        }
        private string _Producer;
        public string Producer
        {
            get { return _Producer; }
            set
            {
                if (value == null || value == string.Empty || value == " ")
                {
                    Console.WriteLine("No Producer found / Try Again. \n");
                }
                else
                {
                    _Producer = value;
                }
            }
        }
        private string _Cast;
        public string Cast
        {
            get { return _Cast; }
            set
            {
                if(value == null || value == string.Empty || value == " ")
                {
                    Console.WriteLine("No cast found \n");
                }
                else
                {
                    _Cast = value;
                }
            }
        }
        private double _Duration;
        public double Duration
        {
            get { return _Duration; }
            set
            {
                if(value <= 0)
                {
                    Console.WriteLine("No Movie found / Duration time doesnt Exisit. \n");
                }
                else
                {
                    _Duration = value;
                }
            }
        }
        private string _Story;
        public string Story
        {
            get { return _Story; }
            set
            {
                if(value == " " || value == null || value == String.Empty)
                {
                    Console.WriteLine("There is no plot to the story \n");
                }
                else
                {
                    _Story = value;
                }
            }
        }
        private string _Type;
        public string Type
        {
            get { return _Type; }
            set
            {
                if(value.Equals("Running", StringComparison.InvariantCultureIgnoreCase) || value.Equals("Upcoming", StringComparison.InvariantCultureIgnoreCase))
                {
                    _Type = value;
                }
                else
                {
                    Console.WriteLine("The type of the story does not exisit. \n");
                }
            }
        }

        public Movie(string Moviename, string Direc, string prod, string Cast_, double Duration_, string Story_, string Type_)
        {
            Random random = new Random();
            this.MovieID = random.Next();
            this.MovieName = Moviename;
            this.Director = Direc;
            this.Producer = prod;  
            this.Cast = Cast_;   
            this.Duration = Duration_;
            this.Story = Story_;
            this.Type = Type_;
        }

        public void DisplayMovieDetails()
        {
            Console.WriteLine("All the details of the Movie Are : \n" + 
                              "Name of the Movie is " + this.MovieName, 
                              "\n Movie ID : " + this.MovieID, 
                              " \n Director Name : " + this.Director,
                              "\n Producer Name : " + this.Producer, 
                              "\n Cast Name : " + this.Cast, 
                              "\n Movie Duration : " + this.Duration, 
                              "\n Story : ", this.Story, 
                              " \n Type : ", this.Story , "\n");
        }

    }

   
}
