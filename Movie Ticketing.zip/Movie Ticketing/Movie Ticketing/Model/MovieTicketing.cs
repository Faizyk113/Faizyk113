﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Ticketing.Model
{
    public class MovieTicketing
    {
        public List<User> UserInformation = new List<User>();
        public List<Theatre> Theatres = new List<Theatre>();
        public List<Movie> Movies = new List<Movie>();
        public List<Show> Shows = new List<Show>();
        public List<Booking> Bookings = new List<Booking>();

        public MovieTicketing()
        {
            User user = new User("Admin", "Admin", "Admin");
            UserInformation = new List<User>();
            UserInformation.Add(user);
        }

        public void AdminMenu()
        {
            int choice;
            int BookingID = 0;
            int MovieID = 0;
            int TheatreID = 0;
            int ShowID = 0;
            do
            {
                Console.WriteLine("Welcome to the Movie booking System. \n");
                Console.WriteLine("------------------------------------------------------\n");
                Console.WriteLine("Choose the preference of What you want. \n");
                Console.WriteLine("1.  Add Theatre.\n  2.  Update Theatre.\n  3.  Add Movie.\n  4.  Update Movie.\n  5.  Add Show.\n  6.  Update Show.\n  7.  Delete Show.\n  8.  Display Theatre.\n  9.  Display Movie.\n  10.  Display Shows.\n   11.  Add Agent.\n  12.  Book Ticket.\n  13.  Print Ticket.\n   14.  Exit.\n");
                Console.WriteLine("-----------------------------------------------------");
                choice = GetChoice();
                switch(choice)
                {
                    case 1:
                        Console.WriteLine("Enter Theatre name");
                        string TheatreName = Console.ReadLine();
                        Console.WriteLine("Enter City name");
                        string CityName = Console.ReadLine();
                        Console.WriteLine("Enter Address");
                        string Address = Console.ReadLine();
                        Console.WriteLine("Enter the Number of seats in the theatre");
                        int NumberOfScreens = Convert.ToInt32(Console.ReadLine());
                        Theatre theatre = new Theatre(TheatreName, CityName, Address, NumberOfScreens);
                        TheatreID = theatre.ThreatreID;
                        Console.WriteLine();
                        break;
                    case 2:
                        Console.WriteLine("Enter Theatre name");
                        string TN = Console.ReadLine();
                        Console.WriteLine("Enter City name");
                        string CN = Console.ReadLine();
                        Console.WriteLine("Enter Address");
                        string ADD = Console.ReadLine();
                        Console.WriteLine("Enter the Number of seats in the theatre");
                        int NOS = Convert.ToInt32(Console.ReadLine());
                        Theatre TH = new Theatre(TN, CN, ADD, NOS);
                        TheatreID = TH.ThreatreID;
                        Console.WriteLine();
                        break;
                    case 3:
                        Console.WriteLine("Enter a movie name");
                        string MovieName = Console.ReadLine();
                        Console.WriteLine("Enter the director name");
                        string Director = Console.ReadLine();
                        Console.WriteLine("Enter the Producers' name");
                        string Producer = Console.ReadLine();
                        Console.WriteLine("Enter the cast of the movie in order of their role weightage");
                        string Cast = Console.ReadLine();
                        Console.WriteLine("Enter the duration of the movie");
                        double Durations = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the story of the movie");
                        string Story = Console.ReadLine();
                        Console.WriteLine("Is the movie 'Upcoming' or 'Running'?");
                        string Type = Console.ReadLine();
                        Movie movie = new Movie(MovieName, Director, Producer, Cast, Durations, Story, Type);
                        MovieID = movie.MovieID;
                        break;
                    case 4:
                        Console.WriteLine("Enter a movie name");
                        string MN = Console.ReadLine();
                        Console.WriteLine("Enter the director name");
                        string DIR = Console.ReadLine();
                        Console.WriteLine("Enter the Producers' name");
                        string PROD = Console.ReadLine();
                        Console.WriteLine("Enter the cast of the movie in order of their role weightage");
                        string CAST = Console.ReadLine();
                        Console.WriteLine("Enter the duration of the movie");
                        double DUR = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the story of the movie");
                        string STORY = Console.ReadLine();
                        Console.WriteLine("Is the movie 'Upcoming' or 'Running'?");
                        string TYPE = Console.ReadLine();
                        Movie mov = new Movie(MN, DIR, PROD, CAST, DUR, STORY, TYPE);
                        MovieID = mov.MovieID;
                        break;
                    case 5:
                        string Name;
                        if (Movies.Count >= 2)
                        {
                            Console.WriteLine("Enter the name of the movie for which you want to add show details");
                            Name = Console.ReadLine();
                            for (int i = 0; i < Movies.Count; i++)
                            {
                                var v = Movies[i];
                                if (v.MovieName == Name)
                                {
                                    MovieID = v.MovieID;
                                }
                            }
                        }
                        string City;
                        if (Theatres.Count >= 2)
                        {
                            Console.WriteLine("Enter the name of the Theatre for which you want to add show details");
                            Name = Console.ReadLine();
                            Console.WriteLine("Enter the city of the theatre for which you want to add show details");
                            City = Console.ReadLine();
                            for (int i = 0; i < Movies.Count; i++)
                            {
                                var v = Theatres[i];
                                if (v.TheatreName.Equals(Name, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    TheatreID = v.ThreatreID;
                                }
                            }
                        }

                        Console.WriteLine("Enter the date of first show");
                        DateTime StartDate = Convert.ToDateTime(Console.ReadLine());
                        DateTime EndDate = StartDate.AddDays(30);
                        Console.WriteLine("Enter the Platinum Seat Rate for the show");
                        decimal PlatinumSeatRate = Convert.ToDecimal(Console.ReadLine());
                        Console.WriteLine("Enter the Gold Seat Rate for the show");
                        decimal GoldSeatRate = Convert.ToDecimal(Console.ReadLine());
                        Console.WriteLine("Enter the Silver Seat Rate for the show");
                        decimal SilverSeatRate = Convert.ToDecimal(Console.ReadLine());
                        Screen screen = new Screen();
                        if (MovieID == 0 || TheatreID == 0)
                        {
                            Console.WriteLine("Enter movie and Theatre details before entering Show details");
                            Console.WriteLine();
                            break;
                        }

                        Show show = new Show(MovieID, TheatreID, Screen.ScreenID, StartDate, EndDate, PlatinumSeatRate, GoldSeatRate, SilverSeatRate);
                        ShowID = show.ShowId;
                        break;
                    case 6:
                        Console.WriteLine("Enter the date of first show");
                        DateTime SD = Convert.ToDateTime(Console.ReadLine());
                        DateTime ED = SD.AddDays(30);
                        Console.WriteLine("Enter the Platinum Seat Rate for the show");
                        decimal PSR = Convert.ToDecimal(Console.ReadLine());
                        Console.WriteLine("Enter the Gold Seat Rate for the show");
                        decimal GSR = Convert.ToDecimal(Console.ReadLine());
                        Console.WriteLine("Enter the Silver Seat Rate for the show");
                        decimal SSR = Convert.ToDecimal(Console.ReadLine());
                        Show sh = new Show(MovieID, TheatreID, Screen.ScreenID, SD, ED, PSR, GSR, SSR);
                        break;
                    case 7:
                        Console.WriteLine("Enter the ShowID of the show which you want to delete");
                        int DelShowID = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 8:
                        List<Theatre> TheatreList = new List<Theatre> { };
                        foreach (var v in TheatreList)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Theatre Name is: {0}", v.TheatreName);
                            Console.WriteLine("City Name is {0}", v.CityName);
                            Console.WriteLine("Address = {0}", v.Address);
                            Console.WriteLine("Number of Screens in the theatre = {0}", v.NumberofScreens);
                            Console.WriteLine();
                        }
                        break;
                    case 9:
                        List<Movie> MovieList = new List<Movie> { };
                        foreach (var v in MovieList)
                        {
                            Console.WriteLine("Movie Name is: {0}", v.MovieName);
                            Console.WriteLine("Director of the movie is: {0}", v.Director);
                            Console.WriteLine("Producers' Name is: {0}", v.Producer);
                            Console.WriteLine("Cast of the movie includes : {0}", v.Cast);
                            Console.WriteLine("Story of the movie is: {0}", v.Story);
                            Console.WriteLine("The Movie is {0} mins long", v.Duration);
                            Console.WriteLine("The movie is {0}", v.Type);
                        }
                        break;
                    case 10:
                        List<Show> ShowList = new List<Show> { };
                        foreach (var v in ShowList)
                        {
                            Console.WriteLine("Date of the first show is: {0}", v.StartDate);
                            Console.WriteLine("Date of the Last show is: {0}", v.EndDate);
                            Console.WriteLine("Movie ID : {0}", v.MovieID);
                            Console.WriteLine("Screen ID : {0}", v.ScreenID);
                            Console.WriteLine("Show ID : {0}", v.ShowId);
                            Console.WriteLine("Theatre ID : {0}", v.TheatreID);
                            Console.WriteLine("Platinum seat rates are : {0}", v.PlatinumSeatRate);
                            Console.WriteLine("Gold seat rates are : {0}", v.GoldSeatRate);
                            Console.WriteLine("Silver seat rates are : {0}", v.SilverSeatRate);
                        }
                        break;
                    case 11:
                        Console.WriteLine("Enter Username");
                        string Username = Console.ReadLine();
                        Console.WriteLine("Enter Password");
                        string Password = Console.ReadLine();
                        Console.WriteLine("Enter User Type");
                        string UserType = Console.ReadLine();
                        User user = new User(Username, Password, UserType);
                        break;
                    case 12:
                        string N;
                        if (Movies.Count >= 2)
                        {
                            Console.WriteLine("Enter the name of the movie for which you want to add show details");
                            N = Console.ReadLine();
                            for (int i = 0; i < Movies.Count; i++)
                            {
                                var v = Movies[i];
                                if (v.MovieName == N)
                                {
                                    MovieID = v.MovieID;
                                }
                            }
                        }
                        string C;
                        if (Theatres.Count >= 2)
                        {
                            Console.WriteLine("Enter the name of the Theatre for which you want to add show details");
                            N = Console.ReadLine();
                            Console.WriteLine("Enter the city of the theatre for which you want to add show details");
                            C = Console.ReadLine();
                            for (int i = 0; i < Movies.Count; i++)
                            {
                                var v = Theatres[i];
                                if (v.TheatreName.Equals(N, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    TheatreID = v.ThreatreID;
                                }
                            }
                        }

                        Screen scr = new Screen();
                        Console.WriteLine("Which seat type do you want to book?\nWe offer platinum, gold and silver tier seats");
                        string SeatTier = Console.ReadLine();
                        Console.WriteLine("How many seats would you like");
                        int NumberOfSeats = Convert.ToInt32(Console.ReadLine());

                        int OldLength = Booking.SeatNumbers.Count;
                        for (int i = 0; i < NumberOfSeats; i++)
                        {
                            int k = 0;
                            do
                            {
                                if (scr.Seats[k] == "Vacant")
                                {
                                    scr.Seats[k] = "Reserved";
                                    Booking.SeatNumbers.Add(k);
                                    break;
                                }
                                k++;
                            } while (k < 50);
                        }

                        int NewLength = Booking.SeatNumbers.Count;
                        if (NewLength - OldLength == NumberOfSeats)
                        {
                            Console.WriteLine("{0} {1} Tier seats are available and have been locked for you!\n", NumberOfSeats, SeatTier);
                            Console.WriteLine("List of Reserved and vacant seats is:");
                            int count = 0;
                            for (int x = 0; x < 50; x++)
                            {
                                if (scr.Seats[x].Equals("Reserved", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    count++;
                                }
                            }
                            Console.WriteLine("There are {0} Reserved and {1} vacant seats available\n", count, 50 - count);
                            Console.WriteLine("The following seat numbers have been locked for you");
                            for (int h = 0; h < NumberOfSeats; h++)
                            {
                                Console.WriteLine(Booking.SeatNumbers[h]);
                            }
                        }
                        else
                        {
                            Console.WriteLine("{0} number of seats are not available. Try leaving a friend at home", NumberOfSeats);
                        }

                        Console.WriteLine("Enter your name now.");
                        string CustomerName = Console.ReadLine();
                        Console.WriteLine("Enter your email address now");
                        string Email = Console.ReadLine();
                        Booking booking = new Booking(ShowID, CustomerName, NumberOfSeats, SeatTier, Email);
                        booking.BookingStatus = "Booked";
                        BookingID = booking.BookingId;
                        break;
                    case 13:
                        Environment.Exit(-1);//Implementation is not there so i cant give logic to this method now
                        break;
                    case 14:
                        Environment.Exit(-1);
                        break;
                }
            }while (choice <= 14);
            
        }

        public void AgentMenu()
        {
            int BookingID = 0;
            int choice;
            string ChosenMovie;

            string MovieName = "Avengers";
            string Director = "Russos Brother";
            string Producer = "Marvels Production";
            string Cast = "Robert downey Jr., Chris Evans, Scarlet Johnson";
            double Duration = 132;
            string Story = "Action, Suspense, Thriller";
            string Type = "Running";
            Movie movie = new Movie(MovieName, Director, Producer, Cast, Duration, Story, Type);

            string MovieName1 = "Uncharted";
            string Director1 = "Ruben Fleicisher";
            string Producer1 = "Avi Arad";
            string Cast1 = "Tom Holland, Sophia Taylor";
            double Duration1 = 138;
            string Story1 = "Based on a game where 2 guys concqure lost gold";
            string Type1 = "Running";
            Movie movie1 = new Movie(MovieName1, Director1, Producer1, Cast1, Duration1, Story1, Type1);
            do
            {
                Console.WriteLine("Enter the Choice. \n");
                Console.WriteLine("1.  View Shows.\n  2.  New Ticket.\n  3.  Print Ticket.\n  4.  Exit.\n");
                Console.WriteLine("-----------------------------------------------------");
                choice = GetChoice();
                switch (choice)
                {
                    case 1:
                        List<Show> ShowList = new List<Show> { };
                        Console.WriteLine("Enter the name of the movie which you want to watch");
                        List<Movie> MoviesList = new List<Movie> { };
                        foreach (var v in MoviesList)
                        {
                            Console.WriteLine("Movie Name is: {0}", v.MovieName);
                            Console.WriteLine("Director of the movie is: {0}", v.Director);
                            Console.WriteLine("Producers' Name is: {0}", v.Producer);
                            Console.WriteLine("Cast of the movie includes : {0}", v.Cast);
                            Console.WriteLine("Story of the movie is: {0}", v.Story);
                            Console.WriteLine("The Movie is {0} mins long", v.Duration);
                            Console.WriteLine("The movie is {0}", v.Type);
                            Console.WriteLine();
                        }
                        ChosenMovie = Console.ReadLine();
                        break;
                    case 2:
                        Screen scr = new Screen();
                        Console.WriteLine("Which seat type do you want to book?\nWe offer platinum, gold and silver tier seats");
                        string SeatTier = Console.ReadLine();
                        Console.WriteLine("How many seats would you like");
                        int NumberOfSeats = Convert.ToInt32(Console.ReadLine());

                        int OldLength = Booking.SeatNumbers.Count;
                        for (int i = 0; i < NumberOfSeats; i++)
                        {
                            int k = 0;
                            do
                            {
                                if (scr.Seats[k] == "Vacant")
                                {
                                    scr.Seats[k] = "Reserved";
                                    Booking.SeatNumbers.Add(k);
                                    break;
                                }
                                k++;
                            } while (k < 50);
                        }
                        int NewLength = Booking.SeatNumbers.Count;
                        if (NewLength - OldLength == NumberOfSeats)
                        {
                            Console.WriteLine("{0} {1} Tier seats are available and have been locked for you!\n", NumberOfSeats, SeatTier);
                            Console.WriteLine("List of Reserved and vacant seats is:");
                            int count = 0;
                            for (int x = 0; x < 50; x++)
                            {
                                if (scr.Seats[x].Equals("Reserved", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    count++;
                                }
                            }
                            Console.WriteLine("There are {0} Reserved and {1} vacant seats available\n", count, 50 - count);
                            Console.WriteLine("The following seat numbers have been locked for you");
                            for (int h = 0; h < NumberOfSeats; h++)
                            {
                                Console.WriteLine(Booking.SeatNumbers[h]);
                            }
                        }
                        else
                        {
                            Console.WriteLine("{0} number of seats are not available. Try leaving a friend at home", NumberOfSeats);
                        }
                        Console.WriteLine("Enter your name now.");
                        string CustomerName = Console.ReadLine();
                        Console.WriteLine("Enter your email address now");
                        string Email = Console.ReadLine();
                        Show SHOW = new Show();
                        Booking booking = new Booking(SHOW.ShowId, CustomerName, NumberOfSeats, SeatTier, Email);
                        BookingID = booking.BookingId;
                        break;
                    case 3:
                        Environment.Exit(-1);//Implementation is not there so i cant give logic to this method now
                        break;
                    case 4:
                        Environment.Exit(-1);
                        break;
                }
            } while (choice <= 4);
        }

        public int GetChoice()
        {
            Console.WriteLine("Enter the Prefreable Choice .\n");
            int choice = Convert.ToInt32(Console.ReadLine());
            return choice;
        }
        public string Login()
        {
            Console.WriteLine("Please Enter the Login ID and Password. \n");
            Console.WriteLine("Enter Username");
            string Username = Console.ReadLine();
            Console.WriteLine("Enter Password");
            string Password = Console.ReadLine();
            foreach (var v in UserInformation)
            {
                if (v.UsernName == Username && v.Password == Password)
                {
                    return v.UserType;
                }
                if (Username != "" && Password != "")
                {
                    return "Agent";
                }
            }
            return null;
        }
    }
    
}
