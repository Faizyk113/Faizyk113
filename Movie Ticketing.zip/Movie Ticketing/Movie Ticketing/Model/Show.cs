﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Ticketing.Model
{
    public class Show
    {
        public int ShowId { get; set; }
        private int _MovieID;
        public int MovieID
        {
            get { return _MovieID; }
            set
            {
                if(value <= 0)
                {
                    Console.WriteLine("There is no Movie Id \n.");
                }
                else
                {
                    _MovieID = value;
                }
            }
        }
        private int _TheatreID;
        public int TheatreID
        {
            get { return _TheatreID; }
            set
            {
                if(value <= 0)
                {
                    Console.WriteLine("The TheatreID does not Exist. \n");
                }
                else
                {
                    _TheatreID = value;
                }
            }
        }
        private int _ScreenID;
        public int ScreenID
        {
            get { return _ScreenID; }
            set
            {
                if(value <= 0)
                {
                    Console.WriteLine("The Screen ID is not There. \n");
                }
                else
                {
                    _ScreenID = value;
                }
            }
        }
        public DateTime StartDate;
        public DateTime EndDate;
        private decimal _PlatinumSeatRate;
        public decimal PlatinumSeatRate
        {
            get
            {
                return _PlatinumSeatRate;
            }
            set
            {
                if( value <= 0)
                {
                    Console.WriteLine("There are no seat Left. \n");
                }
                else
                {
                   _PlatinumSeatRate = value;
                }
            }
        }
        private decimal _GoldSeatRate;
        public decimal GoldSeatRate
        {
            get
            {
                return _GoldSeatRate;
            }
            set
            {
                if(value <= 0)
                {
                    Console.WriteLine("No seats are vacant. \n");
                }
                else
                {
                    _GoldSeatRate = value;
                }
            }
        }
        private decimal _SilverSeatRate;
        public decimal SilverSeatRate
        {
            get
            {
                return _SilverSeatRate;
            }
            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("No seats are vacant. \n");
                }
                else
                {
                    _SilverSeatRate = value;
                }
            }
        }
        public Show()
        {
            Random random = new Random(100000);
            this.ShowId = random.Next();
        }

        public Show(int Movieid_, int TheatreID_, int ScreenID_, DateTime StartDate_, DateTime EndDate_, decimal PlatinumSeatRate_, decimal GoldSeatRate_, decimal SilverSeatRate_)
        {
            Random random = new Random(100000);
            this.ShowId = random.Next();
            this.MovieID = Movieid_;
            this.TheatreID = TheatreID_;
            this.ScreenID = ScreenID_;  
            this.StartDate = StartDate_;
            this.EndDate = EndDate_;
            this.PlatinumSeatRate = PlatinumSeatRate_;
            this.GoldSeatRate = GoldSeatRate_;
            this.SilverSeatRate = SilverSeatRate_;
        }
        public void DisplayShowDetails()
        {
            Console.WriteLine("Show ID is {0}", ShowId);
            Console.WriteLine("Movie ID is {0}", MovieID);
            Console.WriteLine("Theatre ID = {0}", TheatreID);
            Console.WriteLine("ScreenID = {0}", ScreenID);
            Console.WriteLine("First show is on {0}", StartDate);
            Console.WriteLine("Last Show of the movie is on {0}", EndDate);
            Console.WriteLine("Platinum seats of the movie costs {0}", PlatinumSeatRate);
            Console.WriteLine("Gold seats of the movie costs {0}", GoldSeatRate);
            Console.WriteLine("Silver seats of the movie costs {0}\n", SilverSeatRate);
        }
    }
}
