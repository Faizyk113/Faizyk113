﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Ticketing.Model
{
    public class Theatre
    {
        public int ThreatreID { get; set; }
        private string _TheatreName;
        public string TheatreName
        {
            get { return _TheatreName; }
            set
            {
                if(value == null || value == "" || value == string.Empty)
                {
                    Console.WriteLine("Theatre Name doesen't Exist \n");
                }
                else
                {
                    _TheatreName = value;   
                }
            }
        }
        private string _CityName;
        public string CityName
        {
            get { return _CityName; }
            set
            {
                if(string.IsNullOrEmpty(value))
                {
                    Console.WriteLine("City Name does not exist. \n");
                }
                else
                {
                    _CityName = value;
                }
            }
        }
        private string _Address;
        public string Address
        {
            get { return _Address; }
            set
            {
                if(string.IsNullOrEmpty(value))
                {
                    Console.WriteLine("Adress doesn't Exist / No Adress found. \n");
                }
                else
                {
                    _Address = value;   
                }
            }
        }
        private int _NumberofScreens;
        public int NumberofScreens
        {
            get { return _NumberofScreens;}
            set
            {
                if(value <= 0)
                {
                    Console.WriteLine("There are no screen to display. \n");
                }
                else
                {
                    _NumberofScreens = value;
                }
            }
        }
        List<Screen> screens;

        public Theatre(string TheatreName_, string CityName_, string Adress_, int Numberofscreen_)
        {
            Random random = new Random();
            this.ThreatreID = random.Next();
            this.TheatreName = TheatreName_;
            this.CityName = CityName_;  
            this.Address = Adress_;
            this.NumberofScreens = Numberofscreen_;
            this.screens = new List<Screen>(Numberofscreen_);
        }
        public void DisplayTheatreDetails()
        {
            Console.WriteLine("Theatre ID is {0}", this.ThreatreID);
            Console.WriteLine("Name of the theatre is {0}", TheatreName);
            Console.WriteLine("Name of the city is {0}", CityName);
            Console.WriteLine("Address of the theatre is {0}", Address);
            Console.WriteLine("Number of screens are {0}", NumberofScreens);
        }

    }
}
