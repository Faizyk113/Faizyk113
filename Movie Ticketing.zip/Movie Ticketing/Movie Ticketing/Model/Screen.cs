﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Ticketing.Model
{
    public class Screen
    {
        public static int ScreenID;
        public SortedList<int, string> Seats = new SortedList<int, string>();
        public Screen()
        {
            Random random = new Random();
            ScreenID = random.Next(1000, 10000);
            for(int i = 0; i < 50; i++)
            {
                Seats.Add(i, "Vacant");
            }
        }
    }
}
