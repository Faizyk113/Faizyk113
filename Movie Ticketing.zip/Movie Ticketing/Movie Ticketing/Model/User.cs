﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Ticketing.Model
{
    public class User
    {
        private string _UserName;
        public string UsernName
        {
            get { return _UserName; }
            set
            {
                if(value == "" || value == string.Empty || value == null)
                {
                    Console.WriteLine("The UserName is Empty. \n");
                }
                else
                {
                    _UserName = value;
                }
            }
        }
        private string _Password;
        public string Password
        {
            get { return _Password; }
            set
            {
                if (string.IsNullOrEmpty(value) || value == "")
                {
                    Console.WriteLine("Password does not exist. \n");
                }
                else
                {
                    _Password = value;
                }
            }
        }
        private string _UserType;
        public string UserType
        {
            get { return _UserType; }
            set
            {
                if (string.IsNullOrEmpty(value) || value == "")
                {
                    Console.WriteLine("UserType does not exist. \n");
                }
                else
                {
                    _UserType = value;
                }
            }
        }

        public User(string UserName_, string Password_, string UserType_)
        {
            this.UsernName = UserName_;
            this.Password = Password_;
            this.UserType = UserType_;
        }
    }
}
