﻿using System;
using Movie_Ticketing.Model;

namespace Movie_Ticketing
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Theatre t1 = new Theatre("Tanveer ", "Delhi", "Doctor Strange", 3);
            t1.DisplayTheatreDetails();
            MovieTicketing MT = new MovieTicketing();
            string LoginType = MT.Login();
            if (LoginType == null || LoginType == "")
            {
                Console.WriteLine("Invalid username OR password. Please try again");
                LoginType = MT.Login();
            }
            if (LoginType.Equals("Admin", StringComparison.InvariantCultureIgnoreCase))
            {
                MT.AdminMenu();
            }
            if (LoginType.Equals("Agent", StringComparison.InvariantCultureIgnoreCase))
            {
                MT.AgentMenu();
            }
        }
    }
}
