﻿using System;
using Hands_on_assigment_1_Collection_.Model;

namespace Hands_on_assigment_1_Collection_
{
    public class Program
    {
         public static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            EmployeeDAL emd1 = new EmployeeDAL();
            emp1.EmployeeName = "David";
            emp1.EmployeeId = 07;
            emp1.Salary = 62300;
            Employee emp2 = new Employee();
            emp2.EmployeeName = "Ozil";
            emp2.EmployeeId = 10;
            emp2.Salary = 56000;

            Employee emp3 = new Employee();
            emp3.EmployeeName = "Musalia";
            emp3.EmployeeId = 17;
            emp3.Salary = 109998;
            Console.WriteLine(emd1.AddEmployee(emp1));
            Console.WriteLine(emd1.AddEmployee(emp2));
            Console.WriteLine(emd1.AddEmployee(emp3));
            Console.WriteLine(emd1.SearchEmployee(emp1.EmployeeId));
            emd1.GetAllEmployeeistall();
        }
    }
}
