﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Hands_on_assigment_1_Collection_.Model
{
    public class EmployeeDAL : Employee
    {
        ArrayList array1 = new ArrayList();
        public bool AddEmployee(Employee e)
        {
            bool value_ = false;
            if (array1.Contains(e))
            {
                 value_ = false;
            }
            else
            {
                array1.Add(e.EmployeeName);
                array1.Add(e.EmployeeId);
                array1.Add(e.Salary);
            }
            return value_;
        }

        public bool DeleteEmployee(int id)
        {
            bool value_ = false;
            if(array1.Contains(id))
            {
                array1.Remove(id);
                value_ = true;
            }
            else
            {
                value_ = false;
            }
            return value_;
        }
        public string SearchEmployee(int id)
        {
            if(array1.Contains(id))
            {
                return "Employee ID is Present.";
            }
            else
            {
                return "Employe ID is absent";
            }
        }
        public Employee[] GetAllEmployeeistall()
        {
            Employee[] array2 = new Employee[array1.Count];
            foreach(var value in array2)
            {
                Console.WriteLine(value);
            }
            return array2;  
        }
        
    }
}
