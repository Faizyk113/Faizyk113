﻿using System;
using System.Collections;
using System.Collections.Generic;
namespace Generic2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the string containing alphanumeric charachters. \n");
            string alphanumeric = Console.ReadLine();
            char[] AlphaNumeric = alphanumeric.ToCharArray();
            List<char> AlphaList = new List<char>();
            List<char> DigitList = new List<char>();
            for(int i = 0; i < AlphaNumeric.Length; i++)
            {
                if ((AlphaNumeric[i] >= 'A' && AlphaNumeric[i] <= 'Z') || (AlphaNumeric[i] >= 'a' && AlphaNumeric[i] <= 'z'))
                {
                    AlphaList.Add(AlphaNumeric[i]);
                }
                else
                {
                    DigitList.Add(AlphaNumeric[i]);
                }
            }
            AlphaList.Sort();
            DigitList.Sort();
            foreach(var item in AlphaList)
            {
                Console.Write(item);
            }
            Console.WriteLine();

            for(int i = 0; i < DigitList.Count;i++)
            {
                Console.WriteLine(DigitList[i]);
            }
        }
    }
}
