﻿using System;
using System.IO;
using System.Collections.Generic;
using Generic3.Model;

namespace Generic3
{
    public class Program
    {
        static void Main(string[] args)
        {
            AppendCSVFile();
            ReadCSVFile();
            Console.ReadLine();

        }
        static void AppendCSVFile()
        {
            var list = EmployeeData.EmployeeInfo();
            foreach(var i in list)
            {
                File.AppendAllText("EmployeeInfo.csv", $"{i.EmployeeID}, {i.EmployeeName}, {i.Designation},{i.DepartmentName}, {i.JoiningDate} \n");
            }
        }
        static void ReadCSVFile()
        {
            
            var lines = File.ReadAllLines("EmployeeInfo.csv");
            var list = new List<Employee> ();
            foreach (var line in lines)
            {
                var value = line.Split(" , ");
                var employee = new Employee() { EmployeeID = Convert.ToInt32(value[0]), EmployeeName = value[1] , Designation = value [2], DepartmentName = value[3], JoiningDate = Convert.ToDateTime(value[4])};
                list.Add(employee);
            }
            list.ForEach(x => Console.WriteLine($"{x.EmployeeID} \t {x.EmployeeName} \t {x.Designation} \t {x.DepartmentName} \t {x.JoiningDate}"));
        }
    }
}
