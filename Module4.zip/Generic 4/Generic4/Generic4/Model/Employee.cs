﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Generic3.Model
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Designation { get; set; }
        public string DepartmentName { get; set; }

        public DateTime JoiningDate { get; set; }
        
    }

    public class EmployeeData : Employee
    {
        public static List<Employee> EmployeeInfo()
        {
            return new List<Employee>();
            {
                new Employee() { EmployeeID = 1000, EmployeeName = "Tanveer", Designation = "Project Engineer", DepartmentName = "DotNet Framework", JoiningDate = Convert.ToDateTime("29/03/2022") };
                new Employee() { EmployeeID = 2000, EmployeeName = "Faizy", Designation = "Trainee Engineer", DepartmentName = "Java ", JoiningDate = Convert.ToDateTime("01/04/2022") };
                new Employee() { EmployeeID = 3000, EmployeeName = "Ozil", Designation = "Intern", DepartmentName = "SQL", JoiningDate = Convert.ToDateTime("14/03/2022") };
                new Employee() { EmployeeID = 4000, EmployeeName = "Debryune", Designation = "Senior devoleper", DepartmentName = "Python", JoiningDate = Convert.ToDateTime("11/04/2022") };
                new Employee() { EmployeeID = 5000, EmployeeName = "Musalia", Designation = "Quality Engineer", DepartmentName = "Automation", JoiningDate = Convert.ToDateTime("03/04/2022") };
            }
        }

       
    }
}
