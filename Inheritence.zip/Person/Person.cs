﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritence.Model
{
        public class Person
        {
            private string FirstName;
            private string LastName;
            private string EmailAdress;

            private DateTime DateOfBirth;


            public void person(string First_name, string Last_name, string E_mail, DateTime DOB)
            {
                this.FirstName = First_name;
                this.LastName = Last_name;
                this.EmailAdress = E_mail;
                this.DateOfBirth = DOB;
            }

            public bool IsAdult
            {
                get
                {
                    int age = new DateTime(DateTime.Now.Subtract(this.DateOfBirth).Ticks).Year;
                    if (age > 18)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            public string SunSign
            {
                get
                {
                    string Month = this.DateOfBirth.ToString("MMMM");
                    int day = Convert.ToInt32(this.DateOfBirth.ToString("dd"));
                    if (Month == "December")
                    {
                        if (day < 22)
                        {
                            return "Saggatarius";
                        }
                        else
                        {
                            return "Capricorn";
                        }
                    }
                    else if (Month == "January")
                    {
                        if (day < 20)
                        {
                            return "Caprocorn";
                        }
                        else
                        {
                            return "aquarius";
                        }
                    }
                    else if (Month == "February")
                    {
                        if (day < 19)
                        {
                            return "Aquarius";
                        }
                        else
                        {
                            return "pisces";
                        }
                    }
                    else if (Month == "March")
                    {
                        if (day < 21)
                        {
                            return "pisces";
                        }
                        else
                        {
                            return "aries";
                        }
                    }
                    else if (Month == "April")
                    {
                        if (day < 20)
                        {
                            return "aries";
                        }
                        else
                        {
                            return "Taurus";
                        }
                    }
                    else if (Month == "May")
                    {
                        if (day < 21)
                        {
                            return "Taurus";
                        }
                        else
                        {
                            return "Gemini";
                        }
                    }
                    else if (Month == "June")
                    {
                        if (day < 21)
                        {
                            return "Gemini";
                        }
                        else
                        {
                            return "Cancer";
                        }
                    }
                    else if (Month == "July")
                    {
                        if (day < 23)
                        {
                            return "Cancer";
                        }
                        else
                        {
                            return "Leo";
                        }
                    }
                    else if (Month == "August")
                    {
                        if (day < 23)
                        {
                            return "Leo";
                        }
                        else
                        {
                            return "Virgo";
                        }
                    }
                    else if (Month == "September")
                    {
                        if (day < 23)
                        {
                            return "Virgo";
                        }
                        else
                        {
                            return "Libra";
                        }
                    }
                    else if (Month == "October")
                    {
                        if (day < 23)
                        {
                            return "Libra";
                        }
                        else
                        {
                            return "Scorpio";
                        }
                    }
                    else if (Month == "November")
                    {
                        if (day < 23)
                        {
                            return "Scorpio";
                        }
                        else
                        {
                            return "Sagittarius";
                        }
                    }
                    return "";
                }
            }
            public bool IsBirthDay
            {
                get
                {
                    if (DateTime.Now.Month == this.DateOfBirth.Month)
                    {
                        if (DateTime.Now.Day == this.DateOfBirth.Day)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            public string ScreenName
            {
                get
                {
                    char[] c = this.FirstName.ToCharArray();
                    string s1 = Convert.ToString(this.DateOfBirth.Year);
                    char[] c1 = s1.ToCharArray();
                    char[] c3 = c.Concat(c1).ToArray();
                    string screen_name = new string(c3);
                    return screen_name;
                }
            }
        }
}
