﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritence.Model
{
    class Employee : Person
    {
        public double Salary { get; set; }
    }
}
