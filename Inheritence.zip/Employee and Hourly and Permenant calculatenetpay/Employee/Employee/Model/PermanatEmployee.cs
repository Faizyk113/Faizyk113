﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Model
{
    class PermanatEmployee : Person, IPayable
    {
        public double HRA { get; set; }
        public double DA { get; set; }
        public double TAX { get; set; }
        public double NetPay { get; set; }
        public double TotalPay { get; set; }

    
        public void CalculatePay()
        {
            double NetPay_ = (HRA + DA + TAX);
            Console.WriteLine("THe HRA is {0}\n" , HRA +
                                "and DA is {1}\n" , DA +
                                "and TAX is {2}\n"  ,TAX +
                                "and NetPAy is {3}\n" , NetPay_);
        }

    }
}
