﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Model
{
    class HourlyEmployee : Person, IPayable
    {
        public double HoursWorked { get; set; }
        public double PayPerHour { get; set; }

        public void CalculatePay()
        {
            double Income = HoursWorked * PayPerHour;
            Console.WriteLine("The Total Pay is {0} \n", Income);
        }
    }
}
