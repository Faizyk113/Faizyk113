﻿using System;
using Employee.Model;

namespace Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            HourlyEmployee Empl1 = new HourlyEmployee();
            Empl1.FName = "Tanveer";
            Empl1.LName = "Ahmad Khan";
            Empl1.HoursWorked = 8;
            Empl1.PayPerHour = 320;
            Empl1.CalculatePay();
            PermanatEmployee Empl2 = new PermanatEmployee();
            Empl2.FName = "Tom";
            Empl2.LName = "Hiddelston";
            Empl2.HRA = 4500;
            Empl2.DA = 3400;
            Empl2.TAX = 1500;
            Empl2.CalculatePay();
        }
    }
}
