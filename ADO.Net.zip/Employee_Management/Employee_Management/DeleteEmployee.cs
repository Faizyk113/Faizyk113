﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_Management
{
    public partial class DeleteEmployee : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
        public DeleteEmployee()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           try
            {
                SqlConnection con = new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
                int count = 0;
                con.Open();
                string id = textBox1.Text;
                using (SqlCommand cmd = new SqlCommand("SELECT EmployeeID FROM Employee WHERE EmployeeID='" + id + "'", con))
                {
                    try
                    {
                        count = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    catch (NullReferenceException ex)
                    {
                        count = 0;
                        MessageBox.Show("Id is not present.");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Connection to Server Error/User ID does not exists");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                    }
                }
                if (count > 0)
                {
                    string querydelete = "DELETE [EmployeeID], [EmpName], [Designation],[Qualification], [JoiningDate] FROM Employee WHERE EmployeeID = '" + id + "'";
                    try
                    {
                        using (con)
                        {
                            using (SqlCommand cmd = new SqlCommand(querydelete, con))
                            {
                                cmd.ExecuteNonQuery();
                                MessageBox.Show("Successful", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("Connection Lost/  ID doesn't exists");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("No server");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("User ID does not exists");
                }
           }
            catch(Exception ex)
            {
                MessageBox.Show("Connection to Server Error/User ID exists");
                Console.WriteLine(ex);
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
