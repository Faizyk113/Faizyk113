﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_Management
{
    public partial class SearchEmployee : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
        public SearchEmployee()
        {
            InitializeComponent();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            int count = 0;
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
            con.Open();
            string id = idtxt.Text;
            try
            {
                using (SqlCommand cmd = new SqlCommand("SELECT EmployeeID from Employee WHERE EmployeeID = ' " + id + " ' ", con)) 
                {
                    try
                    {
                        count = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    catch (NullReferenceException ex)
                    {
                        count = 0;
                        MessageBox.Show("The Id is not present / Invalid id .");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                        nametxt.Clear();
                        desigtxt.Clear();
                        qualtxt.Clear();
                        dojtxt.Clear(); 
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show("Lost server");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                        this.Hide();
                    }
                }
                if(count > 0)
                {
                    try
                    {

                        SqlCommand cmd1 = new SqlCommand("SELECT [EmpName],[Designation],[Qualification],[JoiningDate] FROM [Employee] WHERE EmployeeID = '" + id + "'", con);
                        using (SqlDataReader dr = cmd1.ExecuteReader())
                        {
                            while(dr.Read())
                            {
                                nametxt.Text = dr["EmpName"].ToString();
                                desigtxt.Text = dr["Designation"].ToString();
                                qualtxt.Text = dr["Qualification"].ToString();
                                dojtxt.Text = dr["JoiningDate"].ToString();
                            }
                        }

                    }
                    catch(SqlException ex)
                    {
                        MessageBox.Show("Something Wrong in server");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                        nametxt.Clear();
                        desigtxt.Clear();
                        qualtxt.Clear();
                        dojtxt.Clear();
                    }
                }
                else
                {
                    MessageBox.Show("User ID does not exists");
                    nametxt.Clear();
                    desigtxt.Clear();
                    qualtxt.Clear();
                    dojtxt.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection to Server Error");
                Console.WriteLine(ex);
                MessageBox.Show(ex.ToString());
            }
        }

        private void backtxt_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
