﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_Management
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
        public Form1()
        {
            con.Open();
            InitializeComponent();
            con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            insertButtonControl1.Hide();
            updateEmployee1.Hide();
            searchEmployee1.Hide();
            deleteEmployee1.Hide();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            insertButtonControl1.Show();
            insertButtonControl1.BringToFront();
            updateEmployee1.Hide();
            searchEmployee1.Hide();
            deleteEmployee1.Hide();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            updateEmployee1.Show();
            insertButtonControl1.Hide();
            updateEmployee1.BringToFront();
            searchEmployee1.Hide();
            deleteEmployee1.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnSerach_Click(object sender, EventArgs e)
        {
            insertButtonControl1.Hide();
            updateEmployee1.Hide();
            searchEmployee1.Show();
            searchEmployee1.BringToFront();
            deleteEmployee1.Hide();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            insertButtonControl1.Hide();
            updateEmployee1.Hide();
            searchEmployee1.Hide();
            deleteEmployee1.Show();
            deleteEmployee1.BringToFront();
        }
    }
}
