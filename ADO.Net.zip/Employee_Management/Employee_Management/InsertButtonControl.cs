﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_Management
{
    public partial class InsertButtonControl : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
        public InsertButtonControl()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
            string id = EmployeIDtxt.Text;
            string Name = EmployeeNametxt.Text;
            string Designation = Designationtxt.Text;
            string Qualification = qualificationtxt.Text;
            DateTime Doj = dateTimePicker1.Value;
            string QueryInsert = "INSERT INTO Employee(EmployeeID,EmpName,Designation,Qualification,JoiningDate)" +
                                 "VALUES ('" + id + "' , ' " + Name + "' , '" + Designation + "' , '" + Qualification + " ' , '" + Doj + " ')";

            try
            {
                con.Open();
                using (con)
                {
                    using(SqlCommand cmd = new SqlCommand(QueryInsert, con))
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Successful", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection didn't connect or ID is not there .");
                Console.WriteLine(ex);
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                EmployeIDtxt.Clear();
                EmployeeNametxt.Clear();
                Designationtxt.Clear();
                qualificationtxt.Clear();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
