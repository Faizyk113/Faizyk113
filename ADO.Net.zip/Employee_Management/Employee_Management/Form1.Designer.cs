﻿namespace Employee_Management
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnSerach = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.Navbar = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.searchEmployee1 = new Employee_Management.SearchEmployee();
            this.updateEmployee1 = new Employee_Management.UpdateEmployee();
            this.insertButtonControl1 = new Employee_Management.InsertButtonControl();
            this.deleteEmployee1 = new Employee_Management.DeleteEmployee();
            this.tableLayoutPanel1.SuspendLayout();
            this.Navbar.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.btnInsert, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnUpdate, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnSerach, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnDelete, 0, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 184F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 157F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(185, 681);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // btnInsert
            // 
            this.btnInsert.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnInsert.Font = new System.Drawing.Font("Sylfaen", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsert.Location = new System.Drawing.Point(3, 3);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(176, 164);
            this.btnInsert.TabIndex = 0;
            this.btnInsert.Text = "Insert Employee";
            this.btnInsert.UseVisualStyleBackColor = false;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.IndianRed;
            this.btnUpdate.Font = new System.Drawing.Font("Sylfaen", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(3, 173);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(179, 164);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.Text = "Update Employee";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnSerach
            // 
            this.btnSerach.BackColor = System.Drawing.Color.OliveDrab;
            this.btnSerach.Font = new System.Drawing.Font("Sylfaen", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSerach.Location = new System.Drawing.Point(3, 343);
            this.btnSerach.Name = "btnSerach";
            this.btnSerach.Size = new System.Drawing.Size(179, 178);
            this.btnSerach.TabIndex = 2;
            this.btnSerach.Text = "Search Employee";
            this.btnSerach.UseVisualStyleBackColor = false;
            this.btnSerach.Click += new System.EventHandler(this.btnSerach_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnDelete.Font = new System.Drawing.Font("Sylfaen", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(3, 527);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(179, 151);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete Employee";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // Navbar
            // 
            this.Navbar.Controls.Add(this.button1);
            this.Navbar.Controls.Add(this.richTextBox1);
            this.Navbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.Navbar.Location = new System.Drawing.Point(185, 0);
            this.Navbar.Name = "Navbar";
            this.Navbar.Size = new System.Drawing.Size(1054, 88);
            this.Navbar.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkRed;
            this.button1.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(968, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 79);
            this.button1.TabIndex = 1;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.richTextBox1.Font = new System.Drawing.Font("Sylfaen", 28F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(0, 3);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(962, 79);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "Employee Management system";
            // 
            // searchEmployee1
            // 
            this.searchEmployee1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.searchEmployee1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.searchEmployee1.Location = new System.Drawing.Point(185, 88);
            this.searchEmployee1.Name = "searchEmployee1";
            this.searchEmployee1.Size = new System.Drawing.Size(1054, 593);
            this.searchEmployee1.TabIndex = 4;
            // 
            // updateEmployee1
            // 
            this.updateEmployee1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.updateEmployee1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.updateEmployee1.Location = new System.Drawing.Point(185, 88);
            this.updateEmployee1.Name = "updateEmployee1";
            this.updateEmployee1.Size = new System.Drawing.Size(1054, 593);
            this.updateEmployee1.TabIndex = 3;
            // 
            // insertButtonControl1
            // 
            this.insertButtonControl1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.insertButtonControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.insertButtonControl1.Location = new System.Drawing.Point(185, 88);
            this.insertButtonControl1.Name = "insertButtonControl1";
            this.insertButtonControl1.Size = new System.Drawing.Size(1054, 593);
            this.insertButtonControl1.TabIndex = 2;
            // 
            // deleteEmployee1
            // 
            this.deleteEmployee1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.deleteEmployee1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.deleteEmployee1.Location = new System.Drawing.Point(185, 88);
            this.deleteEmployee1.Name = "deleteEmployee1";
            this.deleteEmployee1.Size = new System.Drawing.Size(1054, 593);
            this.deleteEmployee1.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1239, 681);
            this.Controls.Add(this.deleteEmployee1);
            this.Controls.Add(this.searchEmployee1);
            this.Controls.Add(this.updateEmployee1);
            this.Controls.Add(this.insertButtonControl1);
            this.Controls.Add(this.Navbar);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.Navbar.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnSerach;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel Navbar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private InsertButtonControl insertButtonControl1;
        private UpdateEmployee updateEmployee1;
        private SearchEmployee searchEmployee1;
        private DeleteEmployee deleteEmployee1;
    }
}

