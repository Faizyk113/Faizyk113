SELECT hire_date from employee where CONVERT(nvarchar(3),hire_date) =('Jan') 
OR CONVERT(nvarchar(3),hire_date) =('Feb') 
OR CONVERT(nvarchar(3),hire_date) =('March') 



