﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Asp.Framework1.Context;

namespace Asp.Framework1
{
    public class Program
    {
        public class Student
        {
            public int StudentID { get; set; }
            public string Name { get; set; }
        }
        public class Course
        {
            public int CourseID { get; set; }
            public string CourseName { get; set; }
        }

        static void Main(string[] args)
        {
            //Inserting The data
            //---------------------------------
            using(var Context = new DbContextSchool())
            {
                var std = new Student() { Name = "Tanveer Ahmad khan" };
                Context.Add(std);
                Context.SaveChanges();
            }

            //----------------------------------------------------------------
            //Update Method
          
            using(var Context = new DbContextSchool())
            {
                var std = Context.Students.First<Student>();
                std.Name = "Faizy Khan";
                Context.SaveChanges();
            }

            //-----------------------------------------------------------------
            //Deleteing Method
            using(var context  = new DbContextSchool())
            {
                var std =  context.Students.First<Student>();
                context.Students.Remove(std);
                context.SaveChanges();
            }
        }
    }
}
