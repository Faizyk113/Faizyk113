﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_Management
{
    public partial class UpdateEmployee : UserControl
    {
        SqlConnection con =  new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
        public UpdateEmployee()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;
            try
            {
                SqlConnection con = new SqlConnection("Data Source=LAPTOP-1KB0IROB;Initial Catalog=EmployeeManagement;Integrated Security=True");
                con.Open();
                string id = idtxt.Text;
                using (SqlCommand cmd = new SqlCommand("SELECT [EmployeeID] from Employee WHERE EmployeeID = '" + id + "'", con))
                {
                    try
                    {
                        count = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    catch (NullReferenceException ex)
                    {
                        count = 0;
                        MessageBox.Show("Connection Lost / User ID invalid ");
                        Console.Write(ex);
                        MessageBox.Show(ex.ToString());
                        this.Hide();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Connection to Server Error/User ID does not exists");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                        this.Hide();
                    }

                }
                if (count > 0)
                {
                    string name = nametxt.Text;
                    string designation = designationtxt.Text;
                    string Qualification = qualificationtxt.Text;
                    DateTime Doj = dateTimePicker1.Value;

                    string QueryUpdate = "UPDATE [Employee] SET EmpName = '" + name + "',Designation='" + designation + "',Qualification='" + Qualification + "',JoiningDate='" + Doj + "' WHERE EmployeeID ='" + id + "'";
                    try
                    {
                        using(con)
                        {
                            using (SqlCommand cmd1 = new SqlCommand(QueryUpdate, con))
                            {
                                cmd1.ExecuteNonQuery();
                                MessageBox.Show("Successful", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    catch(SqlException ex)
                    {
                        MessageBox.Show("Connection Lost/  ID doesn't exists");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show("No server");
                        Console.WriteLine(ex);
                        MessageBox.Show(ex.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Employee doesn't Exisits");
                    nametxt.Clear();
                    designationtxt.Clear();
                    qualificationtxt.Clear();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Server Error / Data Base error. ");
                Console.WriteLine(ex);
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                nametxt.Clear();
                designationtxt.Clear();
                qualificationtxt.Clear();
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
