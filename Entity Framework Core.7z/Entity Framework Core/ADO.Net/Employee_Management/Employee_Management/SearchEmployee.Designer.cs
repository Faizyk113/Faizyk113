﻿namespace Employee_Management
{
    partial class SearchEmployee
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchEmployee));
            this.panel1 = new System.Windows.Forms.Panel();
            this.qualtxt = new System.Windows.Forms.TextBox();
            this.desigtxt = new System.Windows.Forms.TextBox();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.idtxt = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.dojtxt = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnsearch = new System.Windows.Forms.Button();
            this.backtxt = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.backtxt);
            this.panel1.Controls.Add(this.btnsearch);
            this.panel1.Controls.Add(this.dojtxt);
            this.panel1.Controls.Add(this.textBox9);
            this.panel1.Controls.Add(this.idtxt);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.nametxt);
            this.panel1.Controls.Add(this.desigtxt);
            this.panel1.Controls.Add(this.qualtxt);
            this.panel1.Location = new System.Drawing.Point(23, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(898, 595);
            this.panel1.TabIndex = 0;
            // 
            // qualtxt
            // 
            this.qualtxt.Location = new System.Drawing.Point(551, 394);
            this.qualtxt.Name = "qualtxt";
            this.qualtxt.ReadOnly = true;
            this.qualtxt.Size = new System.Drawing.Size(225, 26);
            this.qualtxt.TabIndex = 0;
            // 
            // desigtxt
            // 
            this.desigtxt.Location = new System.Drawing.Point(551, 305);
            this.desigtxt.Name = "desigtxt";
            this.desigtxt.ReadOnly = true;
            this.desigtxt.Size = new System.Drawing.Size(225, 26);
            this.desigtxt.TabIndex = 1;
            // 
            // nametxt
            // 
            this.nametxt.Location = new System.Drawing.Point(551, 219);
            this.nametxt.Name = "nametxt";
            this.nametxt.ReadOnly = true;
            this.nametxt.Size = new System.Drawing.Size(225, 26);
            this.nametxt.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(112, 386);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(246, 34);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "Qualification";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(112, 301);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(246, 34);
            this.textBox5.TabIndex = 4;
            this.textBox5.Text = "Designation";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(112, 215);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(246, 34);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "Employee Name";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(103, 44);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(255, 34);
            this.textBox7.TabIndex = 6;
            this.textBox7.Text = "Enter EmployeeID";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // idtxt
            // 
            this.idtxt.Location = new System.Drawing.Point(551, 48);
            this.idtxt.Name = "idtxt";
            this.idtxt.Size = new System.Drawing.Size(225, 26);
            this.idtxt.TabIndex = 7;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(112, 480);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(246, 34);
            this.textBox9.TabIndex = 8;
            this.textBox9.Text = "Joining Date";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dojtxt
            // 
            this.dojtxt.Location = new System.Drawing.Point(551, 484);
            this.dojtxt.Name = "dojtxt";
            this.dojtxt.ReadOnly = true;
            this.dojtxt.Size = new System.Drawing.Size(225, 26);
            this.dojtxt.TabIndex = 9;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // btnsearch
            // 
            this.btnsearch.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(609, 120);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(121, 51);
            this.btnsearch.TabIndex = 10;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // backtxt
            // 
            this.backtxt.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backtxt.Location = new System.Drawing.Point(151, 120);
            this.backtxt.Name = "backtxt";
            this.backtxt.Size = new System.Drawing.Size(137, 51);
            this.backtxt.TabIndex = 11;
            this.backtxt.Text = "Back";
            this.backtxt.UseVisualStyleBackColor = true;
            this.backtxt.Click += new System.EventHandler(this.backtxt_Click);
            // 
            // SearchEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Controls.Add(this.panel1);
            this.Name = "SearchEmployee";
            this.Size = new System.Drawing.Size(949, 679);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button backtxt;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox dojtxt;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox idtxt;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.TextBox desigtxt;
        private System.Windows.Forms.TextBox qualtxt;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}
