select * from Employees
where title LIKE 'Sales%'
and LastName = 'King' or LastName = 'Jones'