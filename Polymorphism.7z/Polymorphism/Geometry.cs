﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism.Model
{
    public class Geometry
    {
        public virtual double Area()
        {
            return 0.0;
        }
    }
    public class Circle : Geometry
    {
        public double Radius { get; set; }

        public Circle()
        {
            Console.WriteLine("Enter the Radius of the circle \n");
            Radius = Convert.ToDouble(Console.ReadLine());
        }
        public override double Area()
        {
            return 3.14 * Math.Pow(Radius, 2);
        }
    }
    public class Triangle : Geometry
    {
        public double Base { get; set; }
        public double Height { get; set; }  

        public Triangle()
        {
            Console.WriteLine("-------------------------\n");
            Console.WriteLine("Enter the Base of the Triangle.\n");
            Base = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the Height of the triangle. \n");
            Height = Convert.ToDouble(Console.ReadLine());  
        }

        public override double Area()
        {
            return (0.5 *(Base * Height));
        }
    }
    public class Rectangle : Geometry
    {
        public double Length { get; set; }
        public double Width { get; set; } 

        public Rectangle()
        {
            Console.WriteLine("--------------------------\n");
            Console.WriteLine("Enter the Length of rectangle. \n ");
            Length = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the Width of rectangle. \n");
            Width = Convert.ToDouble(Console.ReadLine());   
        }
        public override double Area()
        {
            return Length * Width;
        }
    }
}
